import java.util.*;
class OneTimePad{
	static String generate_key(String msg){
		String key="";
		Random str_ascii=new Random();
		for(int i=0;i<msg.length();i++){
			int n=str_ascii.nextInt(26);
			key=key+(char)(n+97);
		}
		return key;
	}
	static String encryption(String msg,String k){
		String enc_text="";
		for(int i=0;i<msg.length();i++){
			char enc_val=(char)(msg.charAt(i)^k.charAt(i));
			enc_text=enc_text+enc_val;
		}
		return enc_text;
	}
	static String decryption(String msg,String k){
		String dec_text="";
		for(int i=0;i<msg.length();i++){
			char dec_val=(char)(msg.charAt(i)^k.charAt(i));
			dec_text=dec_text+dec_val;
		}
		return dec_text;
	}
	public static void main(String[]args){
		Scanner s=new Scanner(System.in);
		System.out.print("Enter your string::-");
		String message=s.nextLine();
		String key=generate_key(message);
		System.out.println("Key Used For Process : " + key);
		String encrypted_msg=encryption(message,key);
		System.out.println("Your encrypted message is ::"+encrypted_msg);
		String decrypted_msg=decryption(encrypted_msg,key);
		System.out.println("Your decrypted message is ::"+decrypted_msg);

	}
}