import java.util.Scanner;
class Caesar_Cipher{
	Scanner sc;
	String plain_text,cipher_text,decrypted_text;
	Caesar_Cipher(){
		sc=new Scanner(System.in);
		cipher_text="";
		decrypted_text="";
	}
	void getData(){
		System.out.println("Enter Data : ");
		plain_text=sc.nextLine();
		plain_text=plain_text.trim();
	}
	void encryptData(){
		char ch;
		for(int i=0;i<plain_text.length();i++){
			ch=plain_text.charAt(i);
			if(ch>='A' && ch<='Z'){
				ch=(char)(ch+3);
				if(ch>'Z'){
					ch=(char)(ch-'Z'+'A'-1);
				}
				cipher_text=cipher_text+ch;
			}
			else if(ch>='a' && ch<='z'){
				ch=(char)(ch+3);
				if(ch>'z'){
					ch=(char)(ch-'z'+'a'-1);
				}
				cipher_text=cipher_text+ch;
			}
		}
		System.out.println("Cipher Text  :  "+cipher_text);
	}
	void decryptData(){
		char ch;
		for(int i=0;i<cipher_text.length();i++){
			ch=cipher_text.charAt(i);
			if(ch>='A' && ch<='Z'){
				ch=(char)(ch-3);
				if(ch<'A'){
					ch=(char)(ch-'A'+'Z'+1);
				}
				decrypted_text=decrypted_text+ch;
			}
			else if(ch>='a' && ch<='z'){
				ch=(char)(ch+3);
				if(ch<'a'){
					ch=(char)(ch-'a'+'z'+1);
				}
				decrypted_text=decrypted_text+ch;
			}
		}
		System.out.println("Decrypted Text  :  "+decrypted_text);
	}
	public static void main(String args[]){
		Caesar_Cipher cc=new Caesar_Cipher();
		cc.getData();
		cc.encryptData();
		cc.decryptData();
	}
}	