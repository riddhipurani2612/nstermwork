import java.io.*;
import java.util.*;
import java.net.*;
class Client3
{
	public static void main(String args[])throws Exception
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter packet you want to send to server:");
		String packet=sc.nextLine();
		Socket s=new Socket("127.0.0.1",1234);
		DataOutputStream dos=new DataOutputStream(s.getOutputStream());
		dos.writeUTF(packet);
		DataInputStream dis=new DataInputStream(s.getInputStream());
		String server_msg=dis.readUTF();
		System.out.println(server_msg);
		s.close();
	}
}
