import java.io.*;
import java.util.*;
import java.net.*;
class Client1
{
	public static void main(String args[])throws Exception
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the username");
		String uname=sc.nextLine();
		System.out.print("Enter the password");
		String pwd=sc.nextLine();
		Socket s=new Socket("127.0.0.1",5678);
		DataOutputStream dos=new DataOutputStream(s.getOutputStream());
		dos.writeUTF(uname);
		P_Box pbox=new P_Box();
		pbox.doEncryption(pwd);
		dos.writeUTF(encrypt_pwd);
		DataInputStream dis=new DataInputStream(s.getInputStream());
		String msg=dis.readUTF();
		System.out.println(msg);
		s.close();
	}
}
class P_Box{
	public String doEncryption(String s){
		byte p[]=new byte[8];
		byte pTemp[]=new byte[8];
		pTemp=s.getBytes();
		p[0]=pTemp[4];
		p[1]=pTemp[0];
		p[2]=pTemp[5];
		p[3]=pTemp[7];
		p[4]=pTemp[1];
		p[5]=pTemp[3];
		p[6]=pTemp[2];
		p[7]=pTemp[6];
		return(new String(p));
	}
	public String doDecryption(String s){
		byte p[]=new byte[8];
		byte pTemp[]=new byte[8];
		pTemp=s.getBytes();
		p[0]=pTemp[1];
		p[1]=pTemp[4];
		p[2]=pTemp[6];
		p[3]=pTemp[5];
		p[4]=pTemp[0];
		p[5]=pTemp[2];
		p[6]=pTemp[7];
		p[7]=pTemp[3];
		return(new String(p));
	}
}