import java.util.*;
import java.io.*;
import java.net.*;
import java.sql.*;
class prg1_server{
	public static void main(String args[])throws Exception{
		ServerSocket ss=new ServerSocket(5678);
		Socket s=ss.accept();
		DataInputStream dis=new DataInputStream(s.getInputStream());
		String uname=dis.readUTF();
		String e_password=dis.readUTF();
		System.out.println(uname);
		System.out.println(e_password);
		P_Box pbox=new P_Box();
		String d_password=pbox.doDecryption(e_password);
		SHA hash=new SHA();
		String hash_password=hash.doEncryption(d_password);
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/user","root","");
		Statement st= con.createStatement();
		String sql="select password from users where id='"+uname+"';";
		ResultSet rs=st.executeQuery(sql);
		rs.next();
		String hash_password=rs.getString(1);
		con.close();
		DataOutputStream dos=new DataOutputStream(s.getOutputStream());
		if(password.equals(d_password)){
			dos.writeUTF("logged in successfully!");
		}
		else{
			dos.writeUTF("wrong password!!");
		}
	}
}
class P_Box{
	public String doEncryption(String s){
		byte p[]=new byte[8];
		byte pTemp[]=new byte[8];
		pTemp=s.getBytes();
		p[0]=pTemp[4];
		p[1]=pTemp[0];
		p[2]=pTemp[5];
		p[3]=pTemp[7];
		p[4]=pTemp[1];
		p[5]=pTemp[3];
		p[6]=pTemp[2];
		p[7]=pTemp[6];
		return(new String(p));
	}
	public String doDecryption(String s){
		byte p[]=new byte[8];
		byte pTemp[]=new byte[8];
		pTemp=s.getBytes();
		p[0]=pTemp[1];
		p[1]=pTemp[4];
		p[2]=pTemp[6];
		p[3]=pTemp[5];
		p[4]=pTemp[0];
		p[5]=pTemp[2];
		p[6]=pTemp[7];
		p[7]=pTemp[3];
		return(new String(p));
	}
}
class SHA{
	public String doEncryption(String text) throws Exception{
		MessageDigest md=MessageDigest.getInstance("SHA-1");
		byte[] msg=md.digest(text.getBytes());
		BigInteger bigInt=new BigInteger(1,msg);
		String hashValue=bigInt.toString(16);
		while(hashValue.length()<32)
			hashValue+=0+hashValue;
		return hashValue;
	}
}